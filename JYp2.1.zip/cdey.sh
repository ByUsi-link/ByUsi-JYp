pip install python-magic
pip install flask